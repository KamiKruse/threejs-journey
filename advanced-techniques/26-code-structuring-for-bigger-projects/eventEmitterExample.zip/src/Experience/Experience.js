import Sizes from "./Utils/Sizes"

export default class Experience {
  constructor(canvas) {
    window.experience = this
    this.canvas = canvas
    this.size = new Sizes()
    this.size.on('resize', ()=>{
      console.log('window resize occurred ')
    })
  }
}
